/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package tp8_programacion;

import java.util.List;

/**
 *
 * @author alejo
 */
public interface Pagable {
    
    double calcularTotal();
        
}
