/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package tp8_programacion;

/**
 *
 * @author alejo
 */
public interface Notificable {
    
    void notificarCambio(String nuevoEstado);
}
