/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp8_programacion;

/**
 *
 * @author alejo
 */
public class TarjetaCredito implements Pago {

    @Override
    public double procesarPago(double monto) {

        System.out.println("El pago de un total de $" + monto + " a sido procesado");
        return monto;
        
    }
    
    
    
}
