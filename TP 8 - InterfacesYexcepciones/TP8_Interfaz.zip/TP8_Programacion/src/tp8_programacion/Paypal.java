/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp8_programacion;

/**
 *
 * @author alejo
 */
public class Paypal implements PagoConDescuento{

    @Override
    public double aplicarDescuento(double monto, double descuento) {
        double precioFinal = monto * descuento;
        
        return precioFinal;
    }

    @Override
    public double procesarPago(double monto) {
        System.out.println("El pago de un total de $" + monto + " a sido procesado");
        return monto;
    }
    
    
    
}
