 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp8_programacion;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author alejo
 */
public class Pedido implements Pagable {
    private List<Producto> productos = new ArrayList<>();
    private Notificable cliente;

    public Pedido(Notificable cliente) {
        this.cliente = cliente;
    }
    
    
    @Override
    public double calcularTotal() {
        
        double total = 0;
        for (Producto p : productos){
           total += p.calcularTotal();
        }
        
        return total;
    }
    
    public void agregarProducto(Producto nuevoProducto) {
    this.productos.add(nuevoProducto);
    
}
    
    public void cambiarEstado(String nuevoEstado){
        cliente.notificarCambio(nuevoEstado);
    }
    
    
    
    
    
}
