/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.pkg5.ejercicio.pkg3;

/**
 *
 * @author alejo
 */
public class TP5Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("--------Ejercicio 3--------");
        
        Autor autor = new Autor("alejo", "Argentina");
        Editorial editorial = new Editorial("Maped", "caseros 2132");
        Libro libro = new Libro("Titanic","1234567891011",autor,editorial);
        
        System.out.println("Autor: " + libro.getAutor().getNombre() + " de " + libro.getAutor().getNacionalidad());
        System.out.println("Libro: " + libro.getTitulo() + " codigo ISBN = " + libro.getIsbn());
        System.out.println("Editorial: " + libro.getEditorial().getNombre() + " direccion: " + libro.getEditorial().getDireccion());
        
        
    }
    
}
