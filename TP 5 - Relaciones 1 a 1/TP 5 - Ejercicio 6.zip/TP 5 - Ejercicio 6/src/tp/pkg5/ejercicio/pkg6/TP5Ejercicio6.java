/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.pkg5.ejercicio.pkg6;

/**
 *
 * @author alejo
 */
public class TP5Ejercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("--------Ejercicio 6--------");
        
        Cliente cliente = new Cliente("Alejo", 387456215);
        Mesa mesa = new Mesa(8,6);
        Reserva reserva = new Reserva("28/9/25", "19:00", cliente, mesa);
        
        System.out.println("Cliente: " + reserva.getCliente().getNombre() + " - num: " + reserva.getCliente().getTelefono());
        System.out.println("dia reserva: " + reserva.getFecha() + " - hora: " + reserva.getHora());
        System.out.println("Mesa: " + reserva.getMesa().getNumero() + " para " + reserva.getMesa().getCapacidad()+ " personas");
        
        
        
        
    }
    
}
