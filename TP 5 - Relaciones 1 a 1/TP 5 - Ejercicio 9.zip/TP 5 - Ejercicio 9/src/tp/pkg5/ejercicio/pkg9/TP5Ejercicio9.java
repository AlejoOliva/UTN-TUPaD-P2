/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.pkg5.ejercicio.pkg9;

/**
 *
 * @author alejo
 */
public class TP5Ejercicio9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Paciente paciente = new Paciente("Alejo","prevencion");
        Profesional profesional = new Profesional("pepe", "cardiologo");
        CitaMedica cita = new CitaMedica("29/9/25", "19:30" , paciente, profesional);
        
        System.out.println("paciente: " + cita.getPaciente().getNombre() + " - Obra social: " + cita.getPaciente().getObraSocial());
        System.out.println("dia: " + cita.getFecha() + "- hora: " + cita.getHora());
        System.out.println("doctor: " + cita.getProfesional().getNombre() + " - Especialidad: " + cita.getProfesional().getEspecialidad());
        
    }
    
}
