/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.pkg5.ejercicio.pkg14;

/**
 *
 * @author alejo
 */
public class EditorVideo {
    
    public void exportar(String formato, Proyecto proyecto){
        
        Render render = new Render(formato,proyecto);
        
        System.out.println("Se preparo el archivo " + render.getProyecto().getNombre() + " en formato " + render.getFormato() + " con una duracion de " + render.getProyecto().getDuracion());
    }
    
    
}
