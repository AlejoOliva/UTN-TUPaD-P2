/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.pkg5.ejercicio.pkg14;

/**
 *
 * @author alejo
 */
public class TP5Ejercicio14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Proyecto proyecto = new Proyecto("Limon","53 seg");
        EditorVideo editor = new EditorVideo();
        
        editor.exportar("zip", proyecto);
        
        
        
        
    }
    
}
