/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.pkg5.ejercicio.pkg8;

/**
 *
 * @author alejo
 */
public class FirmaDigital {
    private int hash;
    private String fecha;
    private Usuario usuario;
    private Documento documento;
    
    
    public FirmaDigital(int hash, String fecha, Usuario usuario) {
        this.hash = hash;
        this.fecha = fecha;
        this.usuario = usuario;
    }

    public int getHash() {return hash;}
    public String getFecha() {return fecha;}

    /// Parte Usuario
    
    public Usuario getUsuario() {return usuario;}
    public void setUsuario(Usuario usuario) {this.usuario = usuario;}
   
    
    /// Parte Documento
   
    public void setDocumento(Documento documento) {
        this.documento = documento;
        if (documento != null && documento.getFirma() != this) {
            documento.setFirmaDigital(this);
        }
    }
   
    public Documento getDocumento() {return documento;}
    
}
