/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.pkg5.ejercicio.pkg8;

/**
 *
 * @author alejo
 */
public class TP5Ejercicio8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Usuario usuario = new Usuario("Alejo","alejo123@gmail.com");
        FirmaDigital firma = new FirmaDigital(256452,"26/9/25", usuario);
        Documento documento = new Documento("Partida de nacimiento", "datos del nacimiento");
        
        documento.setFirmaDigital(firma); 
        
        System.out.println("Usuario: "+ firma.getUsuario().getNombre() + " - email: " + firma.getUsuario().getEmail());
        System.out.println("Hash de la firma: " + firma.getHash() + " - fecha: "+ firma.getFecha());
        System.out.println("Documento: " + documento.getTitulo() + " - contenido: " + documento.getContenido());
        
    }
    
}
