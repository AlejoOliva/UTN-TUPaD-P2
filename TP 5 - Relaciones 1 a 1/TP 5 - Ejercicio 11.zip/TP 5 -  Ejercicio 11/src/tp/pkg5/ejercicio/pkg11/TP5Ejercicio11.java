/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.pkg5.ejercicio.pkg11;

/**
 *
 * @author alejo
 */
public class TP5Ejercicio11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Artista artista = new Artista("alejo","Trap");
        Cancion cancion = new Cancion("Trapito", artista);
        Reproductor reproductor = new Reproductor();
        
        reproductor.reproducir(cancion);
        
        
    }
    
}
