/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.pkg5.ejercicio.pkg5;

/**
 *
 * @author alejo
 */
public class Computadora {
    private String marca;
    private int numeroSerie;
    private PlacaMadre placa;
    private Propietario propietario;
    
    public Computadora(String marca, int numeroSerie) {
        this.marca = marca;
        this.numeroSerie = numeroSerie;
    }
    
    
    public String getMarca() {return marca;}
    public int getNumeroSerie() {return numeroSerie;}
    
    
    // Para PlacaMadre
    
    public void setPlacaMadre(PlacaMadre placa) {
        this.placa = placa;
        if (placa != null && placa.getComputadora() != this) {
            placa.setComputadora(this);
        }
    }
    
    public PlacaMadre getPlacaMadre() {return placa;}
    
    // Para Propietario
    
     public void setPropietario(Propietario propietario) {
        this.propietario = propietario;
        if (propietario != null && propietario.getComputadora() != this) {
            propietario.setComputadora(this);
        }
    }

    public Propietario getPropietario() {
        return propietario;
    }
}
