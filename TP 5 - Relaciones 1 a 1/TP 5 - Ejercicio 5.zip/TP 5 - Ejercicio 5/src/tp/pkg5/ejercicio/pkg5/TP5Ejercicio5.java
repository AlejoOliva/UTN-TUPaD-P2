/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.pkg5.ejercicio.pkg5;

/**
 *
 * @author alejo
 */
public class TP5Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("--------Ejercicio 5--------");
        
        Computadora compu = new Computadora("Asus",54621);
        PlacaMadre placa = new PlacaMadre("m-4543","a43");
        Propietario propietario = new Propietario("alejo",123456);
        
        compu.setPlacaMadre(placa);
        compu.setPropietario(propietario);
        
        System.out.println("Propietario: " + compu.getPropietario().getNombre() + " - Dni: " + compu.getPropietario().getDni());
        System.out.println("Compu: " + compu.getMarca() + " - num. de serie: " + compu.getNumeroSerie());
        System.out.println("Modelo de Placa: " + compu.getPlacaMadre().getModelo() + " - Chipset: " + compu.getPlacaMadre().getChipset());
    }
    
}
