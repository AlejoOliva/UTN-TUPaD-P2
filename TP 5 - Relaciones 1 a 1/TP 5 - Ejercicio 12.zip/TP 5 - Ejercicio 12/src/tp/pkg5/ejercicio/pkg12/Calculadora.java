/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.pkg5.ejercicio.pkg12;

/**
 *
 * @author alejo
 */
public class Calculadora {
    
    public void calcular(Impuesto impuesto){
        
        System.out.println("El impuesto para el contribuyente " + impuesto.getContribuyente().getNombre()+ " de cuil " + impuesto.getContribuyente().getCuil() +
                            " es de $" + impuesto.getMonto());
    }
}
