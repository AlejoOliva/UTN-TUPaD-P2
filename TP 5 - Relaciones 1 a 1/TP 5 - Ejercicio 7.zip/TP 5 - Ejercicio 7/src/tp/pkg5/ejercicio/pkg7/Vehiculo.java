/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.pkg5.ejercicio.pkg7;

/**
 *
 * @author alejo
 */
public class Vehiculo {
    private String patente;
    private int modelo;
    private Conductor conductor;
    private Motor motor;

    public Vehiculo(String patente, int modelo, Motor motor) {
        this.patente = patente;
        this.modelo = modelo;
        this.motor = motor;
    }

    public int getModelo() {return modelo;}
    public String getPatente() {return patente;}
    
    /// Parte Conductor
    
    public void setConductor(Conductor conductor) {
        this.conductor = conductor;
        if (conductor != null && conductor.getVehiculo() != this) {
            conductor.setVehiculo(this);
        }
    }
    
    public Conductor getConductor() {return conductor;}
    
    /// parte Motor
    
    public Motor getMotor() { return motor; }
    public void setMotor(Motor motor) { this.motor = motor; }
    
    
    
    
}
