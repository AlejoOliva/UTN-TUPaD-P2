/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.pkg5.ejercicio.pkg7;

/**
 *
 * @author alejo
 */
public class TP5Ejercicio7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Motor motor = new Motor("3.0",521623);
        Vehiculo vehiculo = new Vehiculo("AH502PS",2025,motor);
        Conductor conductor = new Conductor("Alejo", 42859201);
        
        conductor.setVehiculo(vehiculo);
        
        System.out.println("Conductor: "+ conductor.getNombre() + "- licencia: " + conductor.getLicencia());
        System.out.println("Patente del vehiculo: " + conductor.getVehiculo().getPatente() + " - Modelo:" + conductor.getVehiculo().getModelo());
        System.out.println("Motor: " + vehiculo.getMotor().getTipo() + " - mum serie: " + vehiculo.getMotor().getNumeroSerie());   
    
    }
}
