/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.pkg5.ejercicio.pkg10;

/**
 *
 * @author alejo
 */
public class TP5Ejercicio10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        CuentaBancaria cuenta = new CuentaBancaria(57207242,28000,"12dashj34","13/9/24");
        Titular titular = new Titular("alejo",4612150);
        
        cuenta.setTitular(titular);
        
        System.out.println("titular: " + cuenta.getTitular().getNombre() + " - dni: " + cuenta.getTitular().getDni());
        System.out.println("cbu: " + cuenta.getCbu() + " - saldo: " + cuenta.getSaldo());
        System.out.println("Codigo: " + cuenta.getClave().getCodigo() + " - Ultima modificacion: " + cuenta.getClave().getModif());
        
    }
    
}
