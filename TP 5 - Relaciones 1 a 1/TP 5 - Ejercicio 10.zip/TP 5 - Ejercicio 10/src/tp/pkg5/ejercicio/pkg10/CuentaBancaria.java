/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.pkg5.ejercicio.pkg10;

/**
 *
 * @author alejo
 */
public class CuentaBancaria {
    private int cbu;
    private int saldo;
    private Titular titular;
    private ClaveSeguridad clave;

    public CuentaBancaria(int cbu, int saldo, String codigo, String modif) {
        this.cbu = cbu;
        this.saldo = saldo;
        this.clave = new ClaveSeguridad(codigo, modif);
    }

    public int getCbu() {return cbu;}
    public int getSaldo() {return saldo;}
    
    // Parte ClaveSeguridad

    public ClaveSeguridad getClave() {return clave;}
    
    
    
    // Parte Titular
    
    public void setTitular(Titular titular) {
        this.titular = titular;
        if (titular != null && titular.getCuenta() != this) {
            titular.setCuentaBancaria(this);
        }
    }

    public Titular getTitular() {return titular;}
    
    
}
