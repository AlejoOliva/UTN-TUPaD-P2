/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.pkg5.ejercicio.pkg10;

/**
 *
 * @author alejo
 */
public class ClaveSeguridad {
    private String codigo;
    private String modif;

    public ClaveSeguridad(String codigo, String modif) {
        this.codigo = codigo;
        this.modif = modif;
    }

    

    public String getCodigo() {return codigo;}
    public String getModif() {return modif;}
    
    
   
    
    
}
