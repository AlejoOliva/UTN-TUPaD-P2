/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.pkg5.ejercicio.pkg13;

/**
 *
 * @author alejo
 */
public class TP5Ejercicio13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Usuario usuario = new Usuario("alejo","alejo@gmail.com");
        GeneradorQR generar = new GeneradorQR();
        
        generar.generador(5421, usuario);
    }
    
}
