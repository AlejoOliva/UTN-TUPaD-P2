/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.pkg5.ejercicio.pkg2;

/**
 *
 * @author alejo
 */
public class Celular {
    
    private int imei;
    private String marca;
    private String modelo;
    private Usuario usuario;
    private Bateria bateria;
    
    public Celular(int numero, String marca, String modelo, Bateria bateria) {
        this.imei = numero;
        this.marca = marca;
        this.modelo = modelo;
        this.bateria = bateria;
    }
    
    public int getImei() { return imei; }
    public String getMarca() { return marca; }
    public String getModelo() { return modelo; }
    

   /// Parte usuario
    
    
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
        if (usuario != null && usuario.getCelular() != this) {
            usuario.setCelular(this);
        }
    }

    public Usuario getUsuario() {
        return usuario;
    }
    
    /// Parte bateria
    
    public Bateria getBateria() { return bateria; }
    public void setBateria(Bateria bateria) { this.bateria = bateria; }
    
    
    
}
    
    
    

