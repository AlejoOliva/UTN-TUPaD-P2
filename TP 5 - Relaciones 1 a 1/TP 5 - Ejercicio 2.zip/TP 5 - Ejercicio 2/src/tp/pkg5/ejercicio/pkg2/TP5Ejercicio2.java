/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.pkg5.ejercicio.pkg2;

/**
 *
 * @author alejo
 */
public class TP5Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("--------Ejercicio 2--------");
        
        Bateria bateria = new Bateria("Samsung-4500mAh", 4500);
        Celular celular = new Celular(45625461, "Samsung", "j2", bateria);
        Usuario usuario = new Usuario("Alejo", 12345678);
        
        usuario.setCelular(celular);

        
        System.out.println("Usuario: " + usuario.getNombre() + " - DNI: " + usuario.getDni());
        System.out.println("Celular: " + celular.getMarca() + " " + celular.getModelo());
        System.out.println("IMEI: " + usuario.getCelular().getImei());
        System.out.println("Bateria: " + usuario.getCelular().getBateria().getModelob() +" (" + usuario.getCelular().getBateria().getCapacidad() + " mAh)");
    }
        
    }
    

