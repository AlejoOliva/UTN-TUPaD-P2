/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.pkg5.ejercicio.pkg4;

/**
 *
 * @author alejo
 */
public class TP5Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        Banco banco = new Banco("BBVA", 456857424);
        TarjetaDeCredito tarjeta = new TarjetaDeCredito(45625461, "28/5/32", banco);
        Cliente cliente = new Cliente("Alejo", 12345678);
        
        cliente.setTarjeta(tarjeta);
        
        System.out.println("cliente: " + cliente.getNombre() + "- dni: " + cliente.getDni());
        System.out.println("Banco: " + cliente.getTarjeta().getBanco().getNombre() + "- CUIT: " + cliente.getTarjeta().getBanco().getCuit());
        System.out.println("Tarjeta: " + cliente.getTarjeta().getNumero() + "- Vencimiento: " + cliente.getTarjeta().getFechaVencimiento());
        
        
    }
    
}
