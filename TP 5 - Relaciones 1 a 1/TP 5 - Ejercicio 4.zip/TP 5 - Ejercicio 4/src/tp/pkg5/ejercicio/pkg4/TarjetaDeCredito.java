/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.pkg5.ejercicio.pkg4;

/**
 *
 * @author alejo
 */
public class TarjetaDeCredito {
    private int numero;
    private String fechaVencimiento;
    private Cliente cliente;
    private Banco banco;
    
    public TarjetaDeCredito(int numero, String fechaVencimiento, Banco banco) {
        this.numero = numero;
        this.fechaVencimiento = fechaVencimiento;
        this.banco = banco;
    }
    
    public int getNumero() { return numero; }
    public String getFechaVencimiento() { return fechaVencimiento; }
    
    // parte Cliente
    
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
        if (cliente != null && cliente.getTarjeta() != this) {
            cliente.setTarjeta(this);
        }
    }

    public Cliente getCliente() {
        return cliente;
    }
    
    // parte Banco
    
    public Banco getBanco() { return banco; }
    public void setBateria(Banco banco) { this.banco = banco; }
    
}
