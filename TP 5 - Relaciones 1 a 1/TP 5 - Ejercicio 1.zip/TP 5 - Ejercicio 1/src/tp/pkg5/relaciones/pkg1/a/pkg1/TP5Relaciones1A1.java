/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.pkg5.relaciones.pkg1.a.pkg1;

/**
 *
 * @author alejo
 */
public class TP5Relaciones1A1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("--------Ejercicio 1--------");
        
        Pasaporte pasaporte1 = new Pasaporte(45621,"28/12/2004");
        Foto foto = new Foto("selfie.png", "png");
        Titular titular = new Titular("Alejo", 12345678);
        
        pasaporte1.setFoto(foto);
        pasaporte1.setTitular(titular);
        
        System.out.println("Numero pasaporte: " + pasaporte1.getFoto().getPasaporte().getNumero());
        System.out.println("Imagen asociada: " + pasaporte1.getFoto().getImagen());
        System.out.println("Titular: " + pasaporte1.getTitular().getNombre() + " - " + pasaporte1.getTitular().getDni());
        
    }
        
    }
    

