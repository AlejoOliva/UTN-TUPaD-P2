/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.pkg6.caso.practico.pkg1;

import java.util.ArrayList;

/**
 *
 * @author alejo
 */
public class Inventario {
    
    private ArrayList <Producto> productos;
    
    public Inventario() {
        this.productos = new ArrayList<>();
    }
    
    
    
    public void agregarProducto(Producto p){
        if (p == null){
            System.out.println("No hay nada que agregar"); 
            return;
        }
        
        for (Producto existente : productos) {
            if (existente.getId().equals(p.getId())) {
                System.out.println("Ya existe un producto con esa id");
                return;
            }
        }
        
        productos.add(p);
        System.out.println("El producto fue agregado con la id " + p.getId());
        
        
    }
    
    
    public void listarProductos(){
        for (Producto p : productos){
            System.out.println("Producto id: " + p.getId()
                              + "- Nombre: " + p.getNombre()
                              + "- Precio: $" + p.getPrecio()
                              + "- Cantidad: " + p.getCantidad()
                              + "- Categoria: " + p.getCategoria().getDescripcion()
            );
            
        }
            
            
    }
    
    public void buscarProductoPorId(String id){
        for (Producto p : productos){
            if (id.equals(p.getId())){
                System.out.println("Producto id: " + p.getId()
                              + "- Nombre: " + p.getNombre()
                              + "- Precio: $" + p.getPrecio()
                              + "- Cantidad: " + p.getCantidad()
                              + "- Categoria: " + p.getCategoria().getDescripcion()
            );
            
            return;
            }  
        }
        System.out.println("No existe un producto con esa id");
        
    }
    
    public void eliminarProducto(String id){
        for (Producto p : productos){
           if (id.equals(p.getId())){
               productos.remove(p);
               return;
           }
        } 
        System.out.println("No se encontro el producto para eliminar");
    }

    public void actualizarStock(String id, int cant){
        for (Producto p : productos){
           if (id.equals(p.getId())){
               p.setCantidad(cant);
               return;
           }
        } 
        System.out.println("No se encontro el producto para actualizar el stock");
    }
   
    public void filtrarPorCategoria(CategoriaProducto categoria){
        System.out.println("Los productos de la categoria " + categoria + " son:");
        for (Producto p : productos){
           if (categoria == p.getCategoria()){
               System.out.println("Producto id: " + p.getId()
                              + "- Nombre: " + p.getNombre()
                              + "- Precio: $" + p.getPrecio()
                              + "- Cantidad: " + p.getCantidad()
                              + "- Categoria: " + p.getCategoria().getDescripcion());
           }
        }
    }
    
    public void obtenerTotalStock(){
        int total_stock = 0;
        for (Producto p : productos){
            total_stock += p.getCantidad();
        } 
        System.out.println("El stock total de todos los productos es de: " + total_stock);
    }
     
    public void obtenerProductoConMayorStock(){
        int stock_ant = 0;
        String id = "0";
        for (Producto p : productos){
            if (p.getCantidad()> stock_ant){
                stock_ant = p.getCantidad();
                id = p.getId();
            }
        } 
        System.out.println("El producto con mayor stock es: ");
        buscarProductoPorId(id);
    }
    
    public void filtrarProductosPorPrecio(double min,double max){
        for (Producto p : productos){
            if (p.getPrecio() > min && p.getPrecio() < max){
                System.out.println("Producto id: " + p.getId()
                              + "- Nombre: " + p.getNombre()
                              + "- Precio: $" + p.getPrecio()
                              + "- Cantidad: " + p.getCantidad()
                              + "- Categoria: " + p.getCategoria().getDescripcion());
            }
        }
    }
    
    public void mostrarCategoriasDisponibles(){
        for (CategoriaProducto c: CategoriaProducto.values()){
            System.out.println(c.name()+ ": " + c.getDescripcion());
        }
        
        
    }
}
