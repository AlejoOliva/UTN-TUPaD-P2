/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.pkg6.caso.practico.pkg1;

/**
 *
 * @author alejo
 */
public class TP6CasoPractico1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Inventario stock = new Inventario();
        
        
        Producto producto1 = new Producto("1","arroz",800,52,CategoriaProducto.ALIMENTOS);
        Producto producto2 = new Producto("2","telefono",2700,4,CategoriaProducto.ELECTRONICA);
        Producto producto3 = new Producto("3","lampara",1500,8,CategoriaProducto.HOGAR);
        Producto producto4 = new Producto("4","remera",1100,14,CategoriaProducto.ROPA);
        Producto producto5 = new Producto("5","chocolate",1300,24,CategoriaProducto.ALIMENTOS);
        
        System.out.println("-----Agregar Productos-----");
        stock.agregarProducto(producto1);
        stock.agregarProducto(producto2);
        stock.agregarProducto(producto3);
        stock.agregarProducto(producto4);
        stock.agregarProducto(producto5);
        
        System.out.println("-----Lista Productos-----");
       stock.listarProductos();
        
        System.out.println("-----Buscar Productos por id-----");
       stock.buscarProductoPorId("4");
       
       System.out.println("-----Eliminar Productos-----");
       stock.eliminarProducto("4");
        
       stock.buscarProductoPorId("4");
       
       System.out.println("-----Actualizar Stock-----");
       stock.actualizarStock("2", 3);
       
       stock.buscarProductoPorId("2");
       
       System.out.println("-----Filtrar por Categorias-----");
       stock.filtrarPorCategoria(CategoriaProducto.ALIMENTOS);
       
       System.out.println("-----Stock total-----");
       stock.obtenerTotalStock();
       
       System.out.println("-----Producto con mayor Stock-----");
       stock.obtenerProductoConMayorStock();
       
       System.out.println("-----Productos por precio-----");
       stock.filtrarProductosPorPrecio(1000, 3000);
       
       System.out.println("-----Categorias Disponibles-----");
       stock.mostrarCategoriasDisponibles();
       
    }
    
}
