/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp6.caso.practico.pkg2;

/**
 *
 * @author alejo
 */
public class TP6CasoPractico2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Biblioteca biblioteca = new Biblioteca();
        
        
        Autor autor1 = new Autor("2812", "Alejo","Argentina");
        Autor autor2 = new Autor("2813", "Rodri","Peru");
        Autor autor3 = new Autor("2814", "Minto","Uruguay");
        
        
        biblioteca.agregarLibro("12345", "El mundo", 2012, autor3);
        biblioteca.agregarLibro("12363", "El espacio", 2014, autor2);
        biblioteca.agregarLibro("12385", "El terreno", 2015, autor1);
        biblioteca.agregarLibro("12397", "El auto", 2018, autor3);
        biblioteca.agregarLibro("12235", "El avion", 2020, autor2);
        
        System.out.println("-------Listar libros-------");
        biblioteca.listarLibros();
        
        System.out.println("-------Buscar libro por ISBN-------");
        biblioteca.buscarLibroPorIsbn("12397");
        
        System.out.println("-------eliminar libro por ISBN-------");
        biblioteca.eliminarLibro("12397");
        
        System.out.println("-------Cantidad total de libros-------");
        biblioteca.obtenerCantidadLibros();
        
        System.out.println("-------filtrar libros por fecha-------");
        biblioteca.filtrarLibrosPorAnio(2014);
        
        System.out.println("-------Autores Disponibles-------");
        biblioteca.mostrarAutoresDisponibles();
        
    }
    
}
