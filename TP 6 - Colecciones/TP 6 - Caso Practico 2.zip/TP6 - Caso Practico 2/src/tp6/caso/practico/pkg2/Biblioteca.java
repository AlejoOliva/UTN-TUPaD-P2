/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp6.caso.practico.pkg2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author alejo
 */
public class Biblioteca {
    
    private String nombre;
    private List <Libro> libros;
    
    public Biblioteca() {
        this.libros = new ArrayList<>();
    }
    
    public void agregarLibro(String isbn, String titulo, int anioPublicacion, Autor autor){
        Libro libro = new Libro(isbn,titulo,anioPublicacion,autor);
        this.libros.add(libro);
    }
    
    public void listarLibros(){
        for (Libro l : libros) {
            l.mostrarInfo();
        }
    }
    
    public void buscarLibroPorIsbn(String isbn){
        for (Libro libro : libros) {
            if (libro.getIsbn().equals(isbn)){
                libro.mostrarInfo();
            }
            
        }
    }
    
    public void eliminarLibro(String isbn){
        for (Libro libro : libros) {
            if (libro.getIsbn().equals(isbn)){
                this.libros.remove(libro);
            }
            
        }
    }
    
    public void obtenerCantidadLibros(){
        int cant_total_libros = 0;
        for (Libro libro : libros) {
            cant_total_libros += 1;
        }
        System.out.println("La cantidad total de libros en la biblioteca son: " + cant_total_libros + " libros");
    }
    
    public void filtrarLibrosPorAnio(int anio){
        for (Libro libro : libros) {
            if (libro.getAnio() == (anio)){
                libro.mostrarInfo();
            }
            
        }
    }
    
    public void mostrarAutoresDisponibles(){
        for (Libro libro : libros) {
            libro.getAutor().mostrarInfo();
            
            
        }
    }
    
    
    
    
}
