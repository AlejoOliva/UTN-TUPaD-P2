/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp6.caso.practico.pkg2;

/**
 *
 * @author alejo
 */
public class Libro {
    
    private String isbn;
    private String titulo;
    private int anio;
    private Autor autor;
    
    
    public void mostrarInfo(){
        System.out.println("Titulo del libro: " + this.titulo);
        System.out.println("ISBN: " + this.isbn);
        System.out.println("Fecha de publicacion: " + this.anio);
        autor.mostrarInfo();
        System.out.println("-");
    }

    public Libro(String isbn, String titulo, int anio, Autor autor) {
        this.isbn = isbn;
        this.titulo = titulo;
        this.anio = anio;
        this.autor = autor;
    }

    public String getIsbn() {
        return isbn;
    }

    public int getAnio() {
        return anio;
    }

    public Autor getAutor() {
        return autor;
    }
    
   
    
    
    
    
    
}
