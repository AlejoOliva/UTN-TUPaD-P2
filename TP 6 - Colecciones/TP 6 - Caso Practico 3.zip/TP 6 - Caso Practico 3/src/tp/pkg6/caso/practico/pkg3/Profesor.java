/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.pkg6.caso.practico.pkg3;

import java.util.List;
import java.util.ArrayList;
/**
 *
 * @author alejo
 */
public class Profesor {
    
    private String id;
    private String nombre;
    private String especialidad;
    private List <Curso> cursos;


    public Profesor(String id, String nombre, String especialidad) {
        this.id = id;
        this.nombre = nombre;
        this.especialidad = especialidad;
        this.cursos = new ArrayList<>();
    }
    
    

    
    public String getNombre() {
        return nombre;
    }
    
    
    
    public void agregarCurso(Curso c){
        cursos.add(c);
        if (c.getProfesor() != this) {
                c.setProfesor(this);
            }
    }
    
    public void eliminarCurso(Curso c){
        if (c == null) return;
        if (cursos.remove(c)) {
            if (c.getProfesor() == this) {
                c.setProfesor(null);
            }
        }
    }
    
    public void listarCursos(){
        for (Curso curso : cursos) {
            curso.mostrarInfo();
            
        }
    }
    
    public void mostrarInfo(){
        System.out.println("Nombre profesor: " + nombre);
        System.out.println("Especialidad: " + especialidad);
        System.out.println("Cursos:");
        for (Curso curso : cursos) {
            System.out.println(curso.getNombre());
        }
        System.out.println("");
    }

    public String getId() {
        return id;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public List<Curso> getCursos() {
        return cursos;
    }
    
    
    
    
    
}
