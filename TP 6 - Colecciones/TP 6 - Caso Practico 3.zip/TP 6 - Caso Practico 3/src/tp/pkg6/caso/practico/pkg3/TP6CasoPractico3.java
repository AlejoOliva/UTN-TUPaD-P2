/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.pkg6.caso.practico.pkg3;

/**
 *
 * @author alejo
 */
public class TP6CasoPractico3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Universidad uni = new Universidad();
        
        Profesor profe1 = new Profesor("1234","Alejo","Matematica");
        Profesor profe2 = new Profesor("4352","Rodri","Sociales");
        Profesor profe3 = new Profesor("6542","Minto","Lengua");
        
        
        Curso curso1 = new Curso("11", "Quimica");
        Curso curso2 = new Curso("12", "Probabilidad");
        Curso curso3 = new Curso("13", "Geografia");
        Curso curso4 = new Curso("14", "Organizacion Empresarial");
        Curso curso5 = new Curso("15", "literatura");
        
        
        uni.agregarProfesor(profe1);
        uni.agregarProfesor(profe2);
        uni.agregarProfesor(profe3);
        
        
        uni.agregarCurso(curso1);
        uni.agregarCurso(curso2);
        uni.agregarCurso(curso3);
        uni.agregarCurso(curso4);
        uni.agregarCurso(curso5);
        
        uni.asignarProfesorACurso("11", "1234");
        uni.asignarProfesorACurso("12", "1234");
        uni.asignarProfesorACurso("13", "4352");
        uni.asignarProfesorACurso("14", "4352");
        uni.asignarProfesorACurso("15", "6542");
        
        
        System.out.println("---------Lista Cursos---------");
        uni.listarCursos();
        
        System.out.println("---------Lista Profesores---------");
        uni.listarProfesores();
        
        System.out.println("---------Cambio Profesor de curso---------");
        curso3.setProfesor(profe1);
        uni.listarProfesores();
        
        System.out.println("---------Remover un curso---------");
        uni.eliminarCurso("13");
        uni.listarProfesores();
        
        System.out.println("---------Remover un Profesor---------");
        uni.eliminarProfesor("4352");
        uni.listarProfesores();
        
        System.out.println("---------Mostrar un Reporte---------");
        uni.reporteCursosPorProfesor();
        
    }
    
}


