/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.pkg6.caso.practico.pkg3;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author alejo
 */
public class Universidad {
    private String nombre;
    private List <Profesor> profesores;
    private List <Curso> cursos;
    
    public Universidad() {
        this.profesores = new ArrayList<>();
        this.cursos = new ArrayList<>();
    }
    
    
    
    public void agregarProfesor(Profesor p){
        this.profesores.add(p);
    }
    
    public void agregarCurso(Curso c){
        this.cursos.add(c);
    }
    
    public void asignarProfesorACurso(String codigoCurso,String idProfesor){
        
        Curso curso = buscarCursoPorCodigo(codigoCurso);
        if (curso == null)return;
        Profesor profesor = buscarProfesorPorId(idProfesor);
        if (profesor == null)return;
        curso.setProfesor(profesor);
        
        
    }
    
    public void listarProfesores(){
        for (Profesor profesore : profesores) {
            profesore.mostrarInfo();
        }
    }
    
    
    
    public void listarCursos(){
        for (Curso curso : cursos) {
            curso.mostrarInfo();
        }
    }
    
    public Profesor buscarProfesorPorId(String id){
        for (Profesor profesore : profesores) {
            if(profesore.getId().equals(id)){
                return profesore;
            }
        }return null;
    }
    
    public Curso buscarCursoPorCodigo(String codigo){
        for (Curso c : cursos) {
            if(c.getCodigo().equals(codigo)){
                return c;
            }
        }return null;
    }
    
    public void eliminarCurso(String codigo){
        Curso curso = buscarCursoPorCodigo(codigo);
        curso.setProfesor(null);
        cursos.remove(codigo);
        
    }
    
    public void eliminarProfesor(String id){
        Profesor profe = buscarProfesorPorId(id);
        if (profe == null) {
        System.out.println("Profesor no encontrado: " + id);
        return;
    }
        for (Curso curso : cursos) {
        Profesor p = curso.getProfesor();   
        if (p != null && id != null && id.equalsIgnoreCase(p.getId())) {
            curso.setProfesor(null);   
        }
    }
        profesores.remove(profe);
    }
    
    public void reporteCursosPorProfesor() {
    for (Profesor p : profesores) {
        int cant = (p.getCursos() != null) ? p.getCursos().size() : 0;
        System.out.println(p.getNombre() + " (" + p.getId() + "): " + cant);
    }
}
}
