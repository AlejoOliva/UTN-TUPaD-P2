/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.pkg6.caso.practico.pkg3;

/**
 *
 * @author alejo
 */
public class Curso {
    
    private String codigo;
    private String nombre;
    private Profesor profesor;

    public Curso(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }
    
    
    
    
    public void mostrarInfo(){
        System.out.println("Curso: " + nombre);
        System.out.println("Codigo: " + codigo);
        if (profesor != null){
            System.out.println("Profesor: " + profesor.getNombre());
        }
        System.out.println("-");
    }

    public Profesor getProfesor() {
        return profesor;
    }
    
    
    
    
    public void setProfesor(Profesor p){
        if (this.profesor == p) return;
        Profesor anterior = this.profesor;
        this.profesor = p;
        if (anterior != null) {
        anterior.eliminarCurso(this);
    }
        if (p != null && !p.getCursos().contains(this)) {
        p.agregarCurso(this);
    }
        
        
       
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }
    
    
    
    
}
