/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.caso.practico.pkg3;

import java.util.ArrayList;

/**
 *
 * @author alejo
 */
public class TPCasoPractico3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Empresa empresa = new Empresa();
        
        EmpleadoPlanta ep1 = new EmpleadoPlanta(500, 4, "Carlos");
        EmpleadoPlanta ep2 = new EmpleadoPlanta(500, 1, "Pepe");
        EmpleadoTemporal ep3 = new EmpleadoTemporal(15, 8, "Roberto");
        EmpleadoTemporal ep4 = new EmpleadoTemporal(15, 4, "Lautaro");
        
        empresa.agregarEmpleados(ep1);
        empresa.agregarEmpleados(ep2);
        empresa.agregarEmpleados(ep3);
        empresa.agregarEmpleados(ep4);
        
        
        empresa.mostrarInfo();
        
    }
    
}
