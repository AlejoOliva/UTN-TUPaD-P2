/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.caso.practico.pkg3;

import java.util.ArrayList;

/**
 *
 * @author alejo
 */
public class Empresa {
    
    private ArrayList < Empleado > empleados;
    
    public Empresa(){
        this.empleados = new ArrayList<>();
    }
    
    public void agregarEmpleados(Empleado e){
        empleados.add(e);
    }
    
    
    
    
    public void mostrarInfo(){
        for (Empleado emp : empleados) {
            System.out.println("El sueldo de " + emp.getNombre() + " es de $" + emp.calcularSueldo());
            if (emp instanceof EmpleadoPlanta){
                System.out.println("Es empleado de Planta");
            }else if (emp instanceof EmpleadoTemporal){
                System.out.println("Es empleado Temporal");
            }
        }
    }
    
    
    
    
}
