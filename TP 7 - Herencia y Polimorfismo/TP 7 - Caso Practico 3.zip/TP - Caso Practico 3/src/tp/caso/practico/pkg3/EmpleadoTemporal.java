/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.caso.practico.pkg3;

import java.util.ArrayList;

/**
 *
 * @author alejo
 */
public class EmpleadoTemporal extends Empleado {
    
    private double sueldo_por_hora;
    private int horas_trabajadas;

    public EmpleadoTemporal(double sueldo_por_hora, int horas_trabajadas, String nombre) {
        super(nombre);
        this.sueldo_por_hora = sueldo_por_hora;
        this.horas_trabajadas = horas_trabajadas;
    }
    
    
    
    
    @Override
    public double calcularSueldo(){
        return sueldo_por_hora * horas_trabajadas;
    }
    
    
}
