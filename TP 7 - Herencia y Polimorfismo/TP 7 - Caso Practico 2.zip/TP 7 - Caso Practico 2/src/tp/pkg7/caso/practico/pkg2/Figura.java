/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.pkg7.caso.practico.pkg2;

import java.util.ArrayList;

/**
 *
 * @author alejo
 */
public abstract class Figura {
    
    protected String nombre;
    private ArrayList <Figura> figuras;

    public Figura(String nombre) {
        this.nombre = nombre;
        this.figuras = new ArrayList<>();
    }
    
    
    
    public abstract double calcularArea();
    
    
}
