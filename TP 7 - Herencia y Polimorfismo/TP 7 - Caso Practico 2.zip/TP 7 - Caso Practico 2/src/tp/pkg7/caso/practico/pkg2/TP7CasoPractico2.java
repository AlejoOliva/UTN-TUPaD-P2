/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.pkg7.caso.practico.pkg2;

/**
 *
 * @author alejo
 */
public class TP7CasoPractico2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        Circulo c1 = new Circulo(4,"Circulo 1");
        Circulo c2 = new Circulo(8,"Circulo 2");
        Rectangulo r1 = new Rectangulo(2,4,"Rectangulo 1");
        Rectangulo r2 = new Rectangulo(4,8,"Rectangulo 2");
        
                
        System.out.println("El area del circulo 1: " + c1.calcularArea());         
        System.out.println("El area del circulo 2: " + c2.calcularArea());        
        System.out.println("El area del rectangulo 1: " + r1.calcularArea());        
        System.out.println("El area del rectangulo 2: " + r2.calcularArea());        
     }
    
}
