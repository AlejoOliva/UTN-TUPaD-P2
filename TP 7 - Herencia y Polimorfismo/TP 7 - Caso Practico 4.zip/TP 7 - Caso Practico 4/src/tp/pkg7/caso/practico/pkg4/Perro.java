/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.pkg7.caso.practico.pkg4;

/**
 *
 * @author alejo
 */
public class Perro extends Animal{

    public Perro(String nombre) {
        super(nombre);
    }
    
    
    @Override
    public void hacerSonido(){
        System.out.println("Guau Guau");
    }
    
    @Override
    public void describirAnimal(){
        System.out.println("Es un perro");
    }
    
}
