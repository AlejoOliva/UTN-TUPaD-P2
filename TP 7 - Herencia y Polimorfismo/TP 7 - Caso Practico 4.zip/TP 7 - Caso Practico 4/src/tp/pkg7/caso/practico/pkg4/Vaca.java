/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.pkg7.caso.practico.pkg4;

/**
 *
 * @author alejo
 */
public class Vaca extends Animal{

    public Vaca(String nombre) {
        super(nombre);
    }
    
    
    @Override
    public void hacerSonido(){
        System.out.println("MUuuu");
    }
    
    @Override
    public void describirAnimal(){
        System.out.println("Es una vaca");
    }
    
    
}
