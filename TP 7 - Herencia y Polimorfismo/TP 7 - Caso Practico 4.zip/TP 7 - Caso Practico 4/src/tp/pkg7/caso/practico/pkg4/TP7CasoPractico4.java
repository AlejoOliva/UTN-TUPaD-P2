/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp.pkg7.caso.practico.pkg4;

/**
 *
 * @author alejo
 */
public class TP7CasoPractico4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Perro perro = new Perro("Luna");
        Gato gato = new Gato("renata");
        Vaca vaca = new Vaca("Bianca");
        
        
        perro.describirAnimal();
        perro.hacerSonido();
        
        gato.describirAnimal();
        perro.hacerSonido();
        
        vaca.describirAnimal();
        vaca.hacerSonido();
        
    }
    
}
