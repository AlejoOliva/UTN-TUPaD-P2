/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp.pkg7.caso.practico.pkg1;

/**
 *
 * @author alejo
 */
public class Auto extends Vehiculo{
    
    private int cantidadPuertas;

    public Auto(String marca, String modelo, int cantidadPuertas) {
        super(marca, modelo);
        this.cantidadPuertas = cantidadPuertas;
    }
    
    @Override
    public void mostrarInfo(){
        System.out.println("marca: " + marca);
        System.out.println("modelo: " + modelo);
        System.out.println("Cantidad de puertas: " + cantidadPuertas);
        
    }
}
